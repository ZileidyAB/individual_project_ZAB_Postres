function clickButton(){
  alert("Usted ha Iniciado Sesión");
}

function Bienvenida(){
  alert('Bienvenido a esta pagina');
}